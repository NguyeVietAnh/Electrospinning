# gitignore-keil
A .gitignore file for Keil projects.
